/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package neuralnetworkgame;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 *
 * @author M
 */
public class NeuralNetworkGame extends JPanel implements Runnable,MouseListener,MouseMotionListener{

    public JPanel panel=new JPanel();
    public JFrame frame=new JFrame("Neural Network Game");
    public Thread thread;
    
    public boolean show_learning=false;
    
    JButton b1=new JButton("Reset Neural Network.");
    JButton b2=new JButton("Show learning process.");
    JButton b3=new JButton("Map 1.");
    
    public int map=1;
    
    public Player player=new Player(80,260);
    
    public Obstacle o1;
    public Obstacle o2;
    public Obstacle o3;
    public Obstacle o4;
    public Obstacle o5;
    
    public ArrayList<Obstacle> obstacles=new ArrayList<Obstacle>();
    
    public boolean network_reach_goal=false;
    public int animation=0,animation_x=0,animation_y=0;;
    
    public boolean doReset=false;
    
    NeuralNetworkGame(int level,boolean sl)
    {
        map=level;
        show_learning=sl;
        
        player=new Player(80,260);
    
        if(map==1){
        o1=new Obstacle(270,170,90,1,0);
        o2=new Obstacle(370,170+90,90,-1,0);
        }
        
        if(map==2){
        o1=new Obstacle(270,170,90,1,1);
        o2=new Obstacle(370,170+90,90,-1,1);
        }
        
        if(map==3){
        o1=new Obstacle(270,170,90,1,0);
        o2=new Obstacle(370,170+90,90,-1,0);
        }
        
        if(map==4){
        o1=new Obstacle(320,220,90,1,2);
        o2=new Obstacle(320,220,90,-1,2);
        }
         
        o3=new Obstacle(370-50,170+90,60,-1,0);
        o4=new Obstacle(370+70,170+0,30,1,0);
        o5=new Obstacle(210,310,50,-1,0);
        
        obstacles.add(o1);
        obstacles.add(o2);
        
        if(map==1){
        obstacles.add(o3);
        obstacles.add(o4);
        obstacles.add(o5);
        }
        
        for(int i=0;i<3000;i++)
        {
            player.randomMove();
        }
        
        this.add(b1);
        this.add(b2);
        this.add(b3);
        
        this.addMouseMotionListener(this);
        this.addMouseListener(this);
        
        b1.addActionListener(new ActionListener()
            {
            public void actionPerformed(ActionEvent ae)
                {
                    /*
                    level++;
                    if(level==4) level=0;
                    lev.setText("Lv "+level);*/
                    System.out.println("b1");
                    show_learning=false;
                    reload();
                }
            }
        );        
        
        b2.addActionListener(new ActionListener()
            {
            public void actionPerformed(ActionEvent ae)
                {
                    
                    System.out.println("b2");
                    show_learning=true;
                    reload();
                }
            }
        );        
        
        b3.addActionListener(new ActionListener()
            {
            public void actionPerformed(ActionEvent ae)
                {
                    
                    map++;
                    if(map==5) map=1;
                    b3.setText("Map "+map+".");
                    System.out.println("b3");
                    
          
                }
            }
        );        
        b3.setText("Map "+map+".");
    }
    
    public void reload()
    {
        frame.dispose();
        NeuralNetworkGame n=new NeuralNetworkGame(map,show_learning);
        
        n.panel = n;
        n.frame = new JFrame("NeuralNetworkGame. 2024.");
        n.frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        n.frame.getContentPane().add(n.panel);
        n.panel.setSize(300, 300);
        n.frame.setLocation(500, 300);
        n.frame.pack();
        n.frame.show();
        n.thread=new Thread(n);
        n.thread.start();
    }
    public static void main(String[] args) {
        NeuralNetworkGame n=new NeuralNetworkGame(1,false);
        n.panel = n;
        n.frame = new JFrame("NeuralNetworkGame. 2024.");
        n.frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        n.frame.getContentPane().add(n.panel);
        n.panel.setSize(300, 300);
        n.frame.setLocation(500, 300);
        n.frame.pack();
        n.frame.show();
        n.thread=new Thread(n);
        n.thread.start();
    }

    @Override
    public void run() {
        
        while(true)
        {
            try{
                
            if(network_reach_goal==false)
            {
                player.makeStep();
                
                if(check_collision(player.x,player.y))
                {
                    player.collide();
                }
                
                for(Obstacle o:obstacles)
                {
                    o.move();
                }
                
            }
            
            if(network_reach_goal==true)
            {
                for(Obstacle o:obstacles)
                {
                    o.move();
                }
            }
            
            
            
            
            
            this.repaint();
            
            if(show_learning==false){
                if(network_reach_goal) Thread.sleep(5); else Thread.sleep(0);
            }
            
            if(show_learning==true){
                if(network_reach_goal) Thread.sleep(5); else Thread.sleep(1);
            }
            
            }catch(Exception exc){};}
        
    }
    
    public Dimension getPreferredSize(){
        return new Dimension(640, 520);
    }
    
    public void paintComponent(Graphics g){
    	super.paintComponent(g);
                
        g.setColor(Color.white);
        g.setColor(new Color(255,255,255));
        g.fillRect(0, 0, 640, 520);
        
        
        g.setColor(new Color(0,255,0));
        g.fillRect(510, 100, 100, 240);
        
        //draw board
        g.setColor(new Color(0,0,0));
        g.drawRect(80-50, 100, 480+100, 240);
        g.drawRect(100+80-50, 100, 50, 190);
        g.drawRect(560-50-100-50+100, 100+50, 50, 190);
        
        g.drawRect(220+10-50,100,180+50,50);
        g.drawRect(220+10,340-50,180+50,50);
        
        g.drawLine(30, 240, 130, 240);
        
        g.drawRect(player.x,player.y,10,10);
        
                for(Obstacle o:obstacles)
                {
                    o.draw(g);
                }
        
        /*
        if(network_reach_goal==true)
        {
     
            int sx=player.start_x;
            int sy=player.start_y;
                    
            for(int i=0;i<player.moves.size();i++)
            {
                g.drawRect(sx,sy,10,10);
                int m=player.moves.get(i);
                if(m==1) sx=sx-3;
                if(m==2) sx=sx+7;
                if(m==3) sy=sy-7;
                if(m==4) sy=sy+7;
            }
        }
        */
        
        if(network_reach_goal==true)
        {
     
            if(animation==0){
                //obstacles.get(0).restart();
                //obstacles.get(1).restart();
                
                for(int i=0;i<obstacles.size();i++)
                {
                Obstacle o=obstacles.get(i);
                o.restart();
                }
                
                animation_x=player.start_x;
                animation_y=player.start_y;
            }       
            
                
                g.drawRect(animation_x,animation_y,10,10);
                int m=player.moves.get(animation);
                
                
                if(m==1) animation_x=animation_x-3;
                if(m==2) animation_x=animation_x+7;
                if(m==3) animation_y=animation_y-7;
                if(m==4) animation_y=animation_y+7;
                
                
                /*
                if(m==1) animation_x=animation_x-2;
                if(m==2) animation_x=animation_x+7;
                if(m==3) animation_y=animation_y-5;
                if(m==4) animation_y=animation_y+5;
                */
                
            animation++;
            if(animation==player.moves.size()) animation=0;
        }
        
        g.setColor(new Color(0,0,0));
        
        g.drawRect(player.last_collision_x,player.last_collision_y,10,10);
            //System.out.println("collision "+check_collision(player.x,player.y));
            
            if(network_reach_goal==false){
                    if(check_collision(player.x,player.y))
                    {
                    g.setColor(new Color(0,0,255));g.fillRect(player.x,player.y,10,10);
                    //player.collide();
                    }
            }
            g.setColor(new Color(0,0,0));
        
    }
    
    public boolean check_collision(int px,int py)
    {
        boolean collision=false;
        
        
        if(px<30||px>610-10||py<100||py>340-10) collision=true;
        
        if(px+10>130&&px<180&&py+10>100&&py<290) collision=true;
        if(px+10>230&&px<460&&py+10>290&&py<340) collision=true;
        if(px+10>460&&px<460+50&&py+10>150&&py<150+190) collision=true;
        if(px+10>180&&px<230+180&&py<150) collision=true;
        if(px+10<=160&&py<=240) collision=true;
        
        
        for(Obstacle o:obstacles)
        {
            
            
            if(o.type==0){
                //if(px>o.x&&px<o.x+10&&py>o.y+10&&py+10<o.y+10)
                if(px>o.x&&px<o.x+10&&py>o.y&&py<o.y+10)
                {
                    collision=true;
                }
            }

            if(o.type==2){
                if(px>o.x&&px<o.x+10&&py>o.y&&py<o.y+10)
                {
                    collision=true;
                }
            }
            
            if(o.type==1)
            {
                //if(px>o.x&&px<o.x+50&&py>o.y+10&&py+10<o.y+40)
                if(px>o.x&&px<o.x+50&&py>o.y&&py<o.y+10)
                {
                    collision=true;
                }
            }
            
        }
        
        if(px>=510) 
        {
            network_reach_goal=true;
            System.out.println("Try "+player.number_of_challenge);
            //System.out.println("steps "+player.moves.size());
            
            for(int i=0;i<obstacles.size();i++)
            {
                Obstacle o=obstacles.get(i);
                o.restart();
            }
        }
        
        return collision;
    }

    @Override
    public void mouseClicked(MouseEvent me) {
        
    }

    @Override
    public void mousePressed(MouseEvent me) {
        
    }

    @Override
    public void mouseReleased(MouseEvent me) {
        
    }

    @Override
    public void mouseEntered(MouseEvent me) {
        
    }

    @Override
    public void mouseExited(MouseEvent me) {
        
    }

    @Override
    public void mouseDragged(MouseEvent me) {
        
    }

    @Override
    public void mouseMoved(MouseEvent me) {
        
    }
}
