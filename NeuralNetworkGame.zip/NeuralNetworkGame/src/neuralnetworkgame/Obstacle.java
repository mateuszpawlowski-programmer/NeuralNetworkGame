/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package neuralnetworkgame;

import java.awt.Graphics;

public class Obstacle {

public float x=0,oldx=0,oldy=0;
public float y=0;

public int animation=0,range=10;

public int dir=1,olddir=1,oldrange=10;

public int type=0;

Obstacle(int px,int py,int r,int d,int t)
{
x=px;y=py;
range=r;
dir=d;
type=t;
oldx=px;oldy=py;olddir=d;oldrange=r;
}

public void restart()
{
this.animation=0;
this.x=oldx;
this.y=oldy;
this.dir=olddir;
this.range=oldrange;  
}

public void move()
{
    if(type==0||type==1){
        animation++;


        if(dir==1)
        {
        y=y+0.2f;
        }

        if(dir==-1)
        {
        y=y-0.2f;
        }


        if(animation==range*5)
        {
            if(dir==1) {dir=-1;} else dir=1;
            animation=0;
        }
    }
    if(type==2)
    {
    animation++;
    
    int alpha=animation;
    float angle=(float)(alpha*3.14/180);
    
    float pxr1=0,pyr1=0;
    
    if(dir==1){
        pxr1=50*(float)Math.cos(angle)-0*(float)Math.sin(angle);
        pyr1=0*(float)Math.cos(angle)+50*(float)Math.sin(angle);
    }
    
    if(dir==-1){
        pxr1=-50*(float)Math.cos(angle)-0*(float)Math.sin(angle);
        pyr1=0*(float)Math.cos(angle)-50*(float)Math.sin(angle);
    }
    
    x=oldx+pxr1;
    y=oldy+pyr1;
    
    if(animation==360) animation=0;
    }
}

public void draw(Graphics g)
{
    if(type==0||type==2) g.drawRect((int)x,(int)y,10,10); 
    if(type==1) {g.drawRect((int)x,(int)y,50,10);};
}

}
