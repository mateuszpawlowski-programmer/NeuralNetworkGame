/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package neuralnetworkgame;

import java.util.ArrayList;
import java.util.Random;



public class Player {

public int x=0;
public int y=0;

public int start_x=0;
public int start_y=0;

public int step=0;

public int last_collision_x=0,last_collision_y=0;

public int number_of_challenge=0;

public Random rnd=new Random();

ArrayList<Integer> moves=new ArrayList<Integer>();


Player(int sx,int sy)
{
rnd.setSeed(System.currentTimeMillis());
x=sx;y=sy;
start_x=sx;start_y=sy;
}

public void randomMove()
{
int rm=rnd.nextInt(4)+1;
//int rm=rnd.nextInt(8)+1;

/*
while(rm==last_collision)
{
    rm=rnd.nextInt(4)+1;
    if(rm!=last_collision) last_collision=0;
}
*/
moves.add(rm);
}

public void makeStep()
{
    if(step<moves.size()){
        int rm=moves.get(step);
        step++;

       
        if(rm==1) x=x-3;
        if(rm==2) x=x+7;
        if(rm==3) y=y-7;
        if(rm==4) y=y+7;
       
        
        /*
        if(rm==1) x=x-2;
        if(rm==2) x=x+7;
        if(rm==3) y=y-5;
        if(rm==4) y=y+5;
        */
        
        /*
        int d=rnd.nextInt(2)+1;
        
        if(rm==5) x=x-d;y=y-d;
        if(rm==6) x=x-d;y=y+d;
        if(rm==7) x=x+d;y=y+d;
        if(rm==8) x=x+d;y=y-d;
        */
        
    }else 
    
    {
        //step=0;x=start_x;y=start_y;
            for(int i=0;i<2;i++)
            {
                randomMove();
            }
    }
}

public void collide()
{
    last_collision_x=x;
    last_collision_y=y;
 
    number_of_challenge++;
    
    ArrayList<Integer> copy_moves=new ArrayList<Integer>();
    //for(int m=0;m<moves.size()-6;m++)
    for(int m=0;m<step-6;m++)
    {
        copy_moves.add(moves.get(m));
    }
    moves=copy_moves;
    
        for(int i=0;i<2;i++)
        {
            randomMove();
        }
        step=0;x=start_x;y=start_y;
}

}
